#include "main_window.h"
#include "Truck.h"
#include <locale>
#include "Expenses.h"
#include "functions.h"
#include <vector>

using namespace System;
using namespace System::Windows::Forms;

vector<Truck*> trucks;
vector<Expense*> exps;



void ElAddTruck(Truck * q){ trucks.push_back(q);}

void ElAddExp(Expense * q){	exps.push_back(q);}

[STAThreadAttribute]
void main(array<String^>^ args) {
	setlocale(LC_ALL, "Russian");
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	trucking::main_window form1(&trucks, &exps);
	Application::Run(%form1);
}