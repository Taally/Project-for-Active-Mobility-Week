#pragma once
#include "Truck.h"
#include <string>
#include <cstring>
#include "Expenses.h"
#include "functions.h"
#include "del.h"
#include "check_today.h"
#include "prevent.h"
#include <algorithm>

using std::string;
using std::all_of;

//����������� ������
void MarshalString ( String ^ s, string& os );

//���������� ����� � ������ 
void ElAddTruck(Truck * q);

//���������� ������� � ������
void ElAddExp(Expense * q);

namespace trucking {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Runtime::InteropServices;

	/// <summary>
	/// ������ ��� main_window
	/// </summary>
	public ref class main_window : public System::Windows::Forms::Form
	{
		bool check_b1;
		bool check_b2;
		bool load_exp;
		bool load_tr;
		bool chn1;
		bool chn2;
		bool chn3;
		bool archive_flag;
	public:
		Truck * data1;
		vector<Truck*> * vectdata1;
		vector<Expense*> * vectdata2;
		vector<Truck*> * vectcheck;
		vector<Truck*> * arc_vectdata1;
		vector<Expense*> * arc_vectdata2;

	private: System::Windows::Forms::Button^  add_exp;
	private: System::Windows::Forms::Button^  show_exp;
	private: System::Windows::Forms::Button^  form_report_exp;
	private: System::Windows::Forms::Button^  back_main_ex;
	private: System::Windows::Forms::PictureBox^  logo;
	private: System::Windows::Forms::RadioButton^  rshort_info;
	private: System::Windows::Forms::RadioButton^  rfull_info;
	private: System::Windows::Forms::TextBox^  text_rfullinfo;
	private: System::Windows::Forms::TextBox^  text_show_truck;
	private: System::Windows::Forms::Button^  change_tr;
	private: System::Windows::Forms::Button^  back_trip2;
	private: System::Windows::Forms::Button^  show_trip_all;
	private: System::Windows::Forms::TextBox^  text_show_data1;
	private: System::Windows::Forms::CheckBox^  change_show1;
	private: System::Windows::Forms::TextBox^  text_show_data2;
	private: System::Windows::Forms::CheckBox^  change_show2;
	private: System::Windows::Forms::TextBox^  text_show_data3;
	private: System::Windows::Forms::CheckBox^  change_show3;
	private: System::Windows::Forms::Button^  back_show_trip;
	private: System::Windows::Forms::Button^  del_trip;
	private: System::Windows::Forms::Button^  cancel_add_trip;
	private: System::Windows::Forms::Label^  lab_ad_ex1;
	private: System::Windows::Forms::Label^  lab_ad_ex2;
	private: System::Windows::Forms::TextBox^  text_ad_ex1;
	private: System::Windows::Forms::DateTimePicker^  text_ad_ex2;
	private: System::Windows::Forms::Button^  cancel_ad_ex;
	private: System::Windows::Forms::Button^  back_ex;
	private: System::Windows::Forms::TextBox^  text_show_allex;
	private: System::Windows::Forms::Button^  back_ex2;
	private: System::Windows::Forms::Button^  del_ex;
	private: System::Windows::Forms::TextBox^  text_del_ex;
	private: System::Windows::Forms::Label^  lab_del_ex;
	private: System::Windows::Forms::RadioButton^  choise_exp1;
	private: System::Windows::Forms::RadioButton^  choise_exp2;
	private: System::Windows::Forms::RadioButton^  choise_exp3;
	private: System::Windows::Forms::Button^  but_good1;
	private: System::Windows::Forms::Button^  arc_but;
	private: System::Windows::Forms::NumericUpDown^  cho_year;
	private: System::Windows::Forms::Label^  lab_arc1;
	private: System::Windows::Forms::Label^  lab_arc2;
	private: System::Windows::Forms::Button^  but_arc1;
	private: System::Windows::Forms::Button^  but_arc_back;
	private: System::Windows::Forms::Button^  but_arc_trip;
	private: System::Windows::Forms::NumericUpDown^  cho_mo;
	private: System::Windows::Forms::Label^  lab_main;
	private: System::Windows::Forms::Button^  but_arc_exp;
	private: System::Windows::Forms::Button^  but_form_exp;
	private: System::Windows::Forms::Button^  but_back_main;
	private: System::Windows::Forms::Button^  but_back_arc;
	private: System::Windows::Forms::Button^  cancel_change_trip;

	public:
		main_window(vector<Truck*> * v, vector<Expense*> * c)
		{
			InitializeComponent();
			vectdata1 = v;
			vectdata2 = c;
			load_exp = false;
			load_tr = false;
			check_b2 = false;
			archive_flag = false;
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~main_window()
		{
			if(data1!=nullptr)
				delete data1;
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  trip;
	private: System::Windows::Forms::Button^  exp;
	private: System::Windows::Forms::Button^  form_report;
	private: System::Windows::Forms::Button^  exit_main;
	private: System::Windows::Forms::Button^  add_trip;
	private: System::Windows::Forms::Button^  show_trip;
	private: System::Windows::Forms::Button^  back_main;
	private: System::Windows::Forms::Label^  lab_ad_trip1;
	private: System::Windows::Forms::TextBox^  text_ad1;
	private: System::Windows::Forms::Label^  lab_ad_trip2;
	private: System::Windows::Forms::Label^  lab_ad_trip3;
	private: System::Windows::Forms::Label^  lab_ad_trip4;
	private: System::Windows::Forms::Label^  lab_ad_trip5;
	private: System::Windows::Forms::TextBox^  text_ad4;
	private: System::Windows::Forms::Button^  back_trip;
	private: System::Windows::Forms::DateTimePicker^  text_ad2;
	private: System::Windows::Forms::DateTimePicker^  text_ad3;
	private: System::Windows::Forms::DateTimePicker^  text_ad5;
	private: System::Windows::Forms::CheckBox^  check_1;

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->trip = (gcnew System::Windows::Forms::Button());
			this->exp = (gcnew System::Windows::Forms::Button());
			this->form_report = (gcnew System::Windows::Forms::Button());
			this->exit_main = (gcnew System::Windows::Forms::Button());
			this->add_trip = (gcnew System::Windows::Forms::Button());
			this->show_trip = (gcnew System::Windows::Forms::Button());
			this->back_main = (gcnew System::Windows::Forms::Button());
			this->lab_ad_trip1 = (gcnew System::Windows::Forms::Label());
			this->text_ad1 = (gcnew System::Windows::Forms::TextBox());
			this->lab_ad_trip2 = (gcnew System::Windows::Forms::Label());
			this->lab_ad_trip3 = (gcnew System::Windows::Forms::Label());
			this->lab_ad_trip4 = (gcnew System::Windows::Forms::Label());
			this->lab_ad_trip5 = (gcnew System::Windows::Forms::Label());
			this->text_ad4 = (gcnew System::Windows::Forms::TextBox());
			this->back_trip = (gcnew System::Windows::Forms::Button());
			this->text_ad2 = (gcnew System::Windows::Forms::DateTimePicker());
			this->text_ad3 = (gcnew System::Windows::Forms::DateTimePicker());
			this->text_ad5 = (gcnew System::Windows::Forms::DateTimePicker());
			this->check_1 = (gcnew System::Windows::Forms::CheckBox());
			this->add_exp = (gcnew System::Windows::Forms::Button());
			this->show_exp = (gcnew System::Windows::Forms::Button());
			this->form_report_exp = (gcnew System::Windows::Forms::Button());
			this->back_main_ex = (gcnew System::Windows::Forms::Button());
			this->logo = (gcnew System::Windows::Forms::PictureBox());
			this->rshort_info = (gcnew System::Windows::Forms::RadioButton());
			this->rfull_info = (gcnew System::Windows::Forms::RadioButton());
			this->text_rfullinfo = (gcnew System::Windows::Forms::TextBox());
			this->text_show_truck = (gcnew System::Windows::Forms::TextBox());
			this->change_tr = (gcnew System::Windows::Forms::Button());
			this->back_trip2 = (gcnew System::Windows::Forms::Button());
			this->show_trip_all = (gcnew System::Windows::Forms::Button());
			this->text_show_data1 = (gcnew System::Windows::Forms::TextBox());
			this->change_show1 = (gcnew System::Windows::Forms::CheckBox());
			this->text_show_data2 = (gcnew System::Windows::Forms::TextBox());
			this->change_show2 = (gcnew System::Windows::Forms::CheckBox());
			this->text_show_data3 = (gcnew System::Windows::Forms::TextBox());
			this->change_show3 = (gcnew System::Windows::Forms::CheckBox());
			this->back_show_trip = (gcnew System::Windows::Forms::Button());
			this->del_trip = (gcnew System::Windows::Forms::Button());
			this->cancel_add_trip = (gcnew System::Windows::Forms::Button());
			this->cancel_change_trip = (gcnew System::Windows::Forms::Button());
			this->lab_ad_ex1 = (gcnew System::Windows::Forms::Label());
			this->lab_ad_ex2 = (gcnew System::Windows::Forms::Label());
			this->text_ad_ex1 = (gcnew System::Windows::Forms::TextBox());
			this->text_ad_ex2 = (gcnew System::Windows::Forms::DateTimePicker());
			this->cancel_ad_ex = (gcnew System::Windows::Forms::Button());
			this->back_ex = (gcnew System::Windows::Forms::Button());
			this->text_show_allex = (gcnew System::Windows::Forms::TextBox());
			this->back_ex2 = (gcnew System::Windows::Forms::Button());
			this->del_ex = (gcnew System::Windows::Forms::Button());
			this->text_del_ex = (gcnew System::Windows::Forms::TextBox());
			this->lab_del_ex = (gcnew System::Windows::Forms::Label());
			this->choise_exp1 = (gcnew System::Windows::Forms::RadioButton());
			this->choise_exp2 = (gcnew System::Windows::Forms::RadioButton());
			this->choise_exp3 = (gcnew System::Windows::Forms::RadioButton());
			this->but_good1 = (gcnew System::Windows::Forms::Button());
			this->arc_but = (gcnew System::Windows::Forms::Button());
			this->cho_year = (gcnew System::Windows::Forms::NumericUpDown());
			this->lab_arc1 = (gcnew System::Windows::Forms::Label());
			this->lab_arc2 = (gcnew System::Windows::Forms::Label());
			this->but_arc1 = (gcnew System::Windows::Forms::Button());
			this->but_arc_back = (gcnew System::Windows::Forms::Button());
			this->but_arc_trip = (gcnew System::Windows::Forms::Button());
			this->cho_mo = (gcnew System::Windows::Forms::NumericUpDown());
			this->lab_main = (gcnew System::Windows::Forms::Label());
			this->but_arc_exp = (gcnew System::Windows::Forms::Button());
			this->but_form_exp = (gcnew System::Windows::Forms::Button());
			this->but_back_main = (gcnew System::Windows::Forms::Button());
			this->but_back_arc = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->logo))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cho_year))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cho_mo))->BeginInit();
			this->SuspendLayout();
			// 
			// trip
			// 
			this->trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->trip->Location = System::Drawing::Point(300, 154);
			this->trip->Name = L"trip";
			this->trip->Size = System::Drawing::Size(190, 70);
			this->trip->TabIndex = 0;
			this->trip->Text = L"�����";
			this->trip->UseVisualStyleBackColor = true;
			this->trip->Click += gcnew System::EventHandler(this, &main_window::trip_Click);
			// 
			// exp
			// 
			this->exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->exp->Location = System::Drawing::Point(300, 245);
			this->exp->Name = L"exp";
			this->exp->Size = System::Drawing::Size(190, 70);
			this->exp->TabIndex = 1;
			this->exp->Text = L"�������";
			this->exp->UseVisualStyleBackColor = true;
			this->exp->Click += gcnew System::EventHandler(this, &main_window::exp_Click);
			// 
			// form_report
			// 
			this->form_report->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->form_report->Location = System::Drawing::Point(300, 336);
			this->form_report->Name = L"form_report";
			this->form_report->Size = System::Drawing::Size(190, 70);
			this->form_report->TabIndex = 2;
			this->form_report->Text = L"������������ ����� � �������";
			this->form_report->UseVisualStyleBackColor = true;
			this->form_report->Click += gcnew System::EventHandler(this, &main_window::form_report_Click);
			// 
			// exit_main
			// 
			this->exit_main->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->exit_main->Location = System::Drawing::Point(660, 545);
			this->exit_main->Name = L"exit_main";
			this->exit_main->Size = System::Drawing::Size(124, 44);
			this->exit_main->TabIndex = 3;
			this->exit_main->Text = L"�����";
			this->exit_main->UseVisualStyleBackColor = true;
			this->exit_main->Click += gcnew System::EventHandler(this, &main_window::exit_main_Click);
			// 
			// add_trip
			// 
			this->add_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->add_trip->Location = System::Drawing::Point(300, 192);
			this->add_trip->Name = L"add_trip";
			this->add_trip->Size = System::Drawing::Size(190, 70);
			this->add_trip->TabIndex = 5;
			this->add_trip->Text = L"�������� ����";
			this->add_trip->UseVisualStyleBackColor = true;
			this->add_trip->Visible = false;
			this->add_trip->Click += gcnew System::EventHandler(this, &main_window::add_trip_Click);
			// 
			// show_trip
			// 
			this->show_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->show_trip->Location = System::Drawing::Point(300, 291);
			this->show_trip->Name = L"show_trip";
			this->show_trip->Size = System::Drawing::Size(190, 70);
			this->show_trip->TabIndex = 6;
			this->show_trip->Text = L"�������� ���������� � ������";
			this->show_trip->UseVisualStyleBackColor = true;
			this->show_trip->Visible = false;
			this->show_trip->Click += gcnew System::EventHandler(this, &main_window::show_trip_Click);
			// 
			// back_main
			// 
			this->back_main->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_main->Location = System::Drawing::Point(661, 545);
			this->back_main->Name = L"back_main";
			this->back_main->Size = System::Drawing::Size(123, 43);
			this->back_main->TabIndex = 7;
			this->back_main->Text = L"�����";
			this->back_main->UseVisualStyleBackColor = true;
			this->back_main->Visible = false;
			this->back_main->Click += gcnew System::EventHandler(this, &main_window::back_main_Click);
			// 
			// lab_ad_trip1
			// 
			this->lab_ad_trip1->AutoSize = true;
			this->lab_ad_trip1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_trip1->Location = System::Drawing::Point(36, 154);
			this->lab_ad_trip1->Name = L"lab_ad_trip1";
			this->lab_ad_trip1->Size = System::Drawing::Size(272, 23);
			this->lab_ad_trip1->TabIndex = 8;
			this->lab_ad_trip1->Text = L"������� �������� �����:";
			this->lab_ad_trip1->Visible = false;
			// 
			// text_ad1
			// 
			this->text_ad1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad1->Location = System::Drawing::Point(384, 156);
			this->text_ad1->Name = L"text_ad1";
			this->text_ad1->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->text_ad1->Size = System::Drawing::Size(381, 32);
			this->text_ad1->TabIndex = 9;
			this->text_ad1->Visible = false;
			// 
			// lab_ad_trip2
			// 
			this->lab_ad_trip2->AutoSize = true;
			this->lab_ad_trip2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_trip2->Location = System::Drawing::Point(36, 192);
			this->lab_ad_trip2->Name = L"lab_ad_trip2";
			this->lab_ad_trip2->Size = System::Drawing::Size(134, 22);
			this->lab_ad_trip2->TabIndex = 10;
			this->lab_ad_trip2->Text = L"���� �����: ";
			this->lab_ad_trip2->Visible = false;
			// 
			// lab_ad_trip3
			// 
			this->lab_ad_trip3->AutoSize = true;
			this->lab_ad_trip3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_trip3->Location = System::Drawing::Point(36, 231);
			this->lab_ad_trip3->Name = L"lab_ad_trip3";
			this->lab_ad_trip3->Size = System::Drawing::Size(200, 22);
			this->lab_ad_trip3->TabIndex = 11;
			this->lab_ad_trip3->Text = L"���� ������� ����: ";
			this->lab_ad_trip3->Visible = false;
			// 
			// lab_ad_trip4
			// 
			this->lab_ad_trip4->AutoSize = true;
			this->lab_ad_trip4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_trip4->Location = System::Drawing::Point(36, 268);
			this->lab_ad_trip4->Name = L"lab_ad_trip4";
			this->lab_ad_trip4->Size = System::Drawing::Size(174, 22);
			this->lab_ad_trip4->TabIndex = 12;
			this->lab_ad_trip4->Text = L"����� �������: ";
			this->lab_ad_trip4->Visible = false;
			// 
			// lab_ad_trip5
			// 
			this->lab_ad_trip5->AutoSize = true;
			this->lab_ad_trip5->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_trip5->Location = System::Drawing::Point(36, 384);
			this->lab_ad_trip5->Name = L"lab_ad_trip5";
			this->lab_ad_trip5->Size = System::Drawing::Size(249, 22);
			this->lab_ad_trip5->TabIndex = 13;
			this->lab_ad_trip5->Text = L"���� ��������� �������: ";
			this->lab_ad_trip5->Visible = false;
			// 
			// text_ad4
			// 
			this->text_ad4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad4->Location = System::Drawing::Point(384, 270);
			this->text_ad4->Name = L"text_ad4";
			this->text_ad4->Size = System::Drawing::Size(381, 32);
			this->text_ad4->TabIndex = 17;
			this->text_ad4->Visible = false;
			// 
			// back_trip
			// 
			this->back_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_trip->Location = System::Drawing::Point(660, 532);
			this->back_trip->Name = L"back_trip";
			this->back_trip->Size = System::Drawing::Size(124, 57);
			this->back_trip->TabIndex = 19;
			this->back_trip->Text = L"��������� � �����";
			this->back_trip->UseVisualStyleBackColor = true;
			this->back_trip->Visible = false;
			this->back_trip->Click += gcnew System::EventHandler(this, &main_window::back_trip_Click);
			// 
			// text_ad2
			// 
			this->text_ad2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad2->Location = System::Drawing::Point(384, 194);
			this->text_ad2->MinDate = System::DateTime(2000, 1, 1, 0, 0, 0, 0);
			this->text_ad2->Name = L"text_ad2";
			this->text_ad2->Size = System::Drawing::Size(223, 32);
			this->text_ad2->TabIndex = 20;
			this->text_ad2->Visible = false;
			// 
			// text_ad3
			// 
			this->text_ad3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad3->Location = System::Drawing::Point(384, 232);
			this->text_ad3->MinDate = System::DateTime(2000, 1, 1, 0, 0, 0, 0);
			this->text_ad3->Name = L"text_ad3";
			this->text_ad3->Size = System::Drawing::Size(223, 32);
			this->text_ad3->TabIndex = 21;
			this->text_ad3->Visible = false;
			// 
			// text_ad5
			// 
			this->text_ad5->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad5->Location = System::Drawing::Point(383, 384);
			this->text_ad5->MinDate = System::DateTime(2000, 1, 1, 0, 0, 0, 0);
			this->text_ad5->Name = L"text_ad5";
			this->text_ad5->Size = System::Drawing::Size(223, 32);
			this->text_ad5->TabIndex = 22;
			this->text_ad5->Visible = false;
			// 
			// check_1
			// 
			this->check_1->AutoSize = true;
			this->check_1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->check_1->Location = System::Drawing::Point(553, 316);
			this->check_1->Name = L"check_1";
			this->check_1->Size = System::Drawing::Size(212, 26);
			this->check_1->TabIndex = 23;
			this->check_1->Text = L"������� ��������\?";
			this->check_1->UseVisualStyleBackColor = true;
			this->check_1->Visible = false;
			this->check_1->CheckedChanged += gcnew System::EventHandler(this, &main_window::check_1_CheckedChanged);
			// 
			// add_exp
			// 
			this->add_exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->add_exp->Location = System::Drawing::Point(300, 156);
			this->add_exp->Name = L"add_exp";
			this->add_exp->Size = System::Drawing::Size(190, 70);
			this->add_exp->TabIndex = 26;
			this->add_exp->Text = L"�������� ������";
			this->add_exp->UseVisualStyleBackColor = true;
			this->add_exp->Visible = false;
			this->add_exp->Click += gcnew System::EventHandler(this, &main_window::add_exp_Click);
			// 
			// show_exp
			// 
			this->show_exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->show_exp->Location = System::Drawing::Point(300, 260);
			this->show_exp->Name = L"show_exp";
			this->show_exp->Size = System::Drawing::Size(190, 70);
			this->show_exp->TabIndex = 27;
			this->show_exp->Text = L"�������� ���������� �� ��������";
			this->show_exp->UseVisualStyleBackColor = true;
			this->show_exp->Visible = false;
			this->show_exp->Click += gcnew System::EventHandler(this, &main_window::show_exp_Click);
			// 
			// form_report_exp
			// 
			this->form_report_exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->form_report_exp->Location = System::Drawing::Point(300, 367);
			this->form_report_exp->Name = L"form_report_exp";
			this->form_report_exp->Size = System::Drawing::Size(190, 70);
			this->form_report_exp->TabIndex = 28;
			this->form_report_exp->Text = L"������������ ����� � ��������";
			this->form_report_exp->UseVisualStyleBackColor = true;
			this->form_report_exp->Visible = false;
			this->form_report_exp->Click += gcnew System::EventHandler(this, &main_window::form_report_exp_Click);
			// 
			// back_main_ex
			// 
			this->back_main_ex->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_main_ex->Location = System::Drawing::Point(660, 534);
			this->back_main_ex->Name = L"back_main_ex";
			this->back_main_ex->Size = System::Drawing::Size(124, 57);
			this->back_main_ex->TabIndex = 29;
			this->back_main_ex->Text = L"�����";
			this->back_main_ex->UseVisualStyleBackColor = true;
			this->back_main_ex->Visible = false;
			this->back_main_ex->Click += gcnew System::EventHandler(this, &main_window::back_main_ex_Click);
			// 
			// logo
			// 
			this->logo->ImageLocation = L"logo1-inv.png";
			this->logo->Location = System::Drawing::Point(12, 441);
			this->logo->Name = L"logo";
			this->logo->Size = System::Drawing::Size(150, 148);
			this->logo->TabIndex = 30;
			this->logo->TabStop = false;
			// 
			// rshort_info
			// 
			this->rshort_info->AutoSize = true;
			this->rshort_info->Checked = true;
			this->rshort_info->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->rshort_info->Location = System::Drawing::Point(25, 78);
			this->rshort_info->Name = L"rshort_info";
			this->rshort_info->Size = System::Drawing::Size(406, 27);
			this->rshort_info->TabIndex = 31;
			this->rshort_info->TabStop = true;
			this->rshort_info->Text = L"������� ���������� � ���� ������";
			this->rshort_info->UseVisualStyleBackColor = true;
			this->rshort_info->Visible = false;
			this->rshort_info->CheckedChanged += gcnew System::EventHandler(this, &main_window::rshort_info_CheckedChanged);
			// 
			// rfull_info
			// 
			this->rfull_info->AutoSize = true;
			this->rfull_info->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->rfull_info->Location = System::Drawing::Point(25, 110);
			this->rfull_info->Name = L"rfull_info";
			this->rfull_info->Size = System::Drawing::Size(497, 27);
			this->rfull_info->TabIndex = 32;
			this->rfull_info->Text = L"������ ���������� � ����� ��� �������: ";
			this->rfull_info->UseVisualStyleBackColor = true;
			this->rfull_info->Visible = false;
			this->rfull_info->CheckedChanged += gcnew System::EventHandler(this, &main_window::rfull_info_CheckedChanged);
			// 
			// text_rfullinfo
			// 
			this->text_rfullinfo->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_rfullinfo->Location = System::Drawing::Point(528, 105);
			this->text_rfullinfo->Name = L"text_rfullinfo";
			this->text_rfullinfo->ReadOnly = true;
			this->text_rfullinfo->Size = System::Drawing::Size(44, 32);
			this->text_rfullinfo->TabIndex = 33;
			this->text_rfullinfo->Visible = false;
			// 
			// text_show_truck
			// 
			this->text_show_truck->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_show_truck->Location = System::Drawing::Point(12, 145);
			this->text_show_truck->Multiline = true;
			this->text_show_truck->Name = L"text_show_truck";
			this->text_show_truck->ReadOnly = true;
			this->text_show_truck->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->text_show_truck->Size = System::Drawing::Size(595, 446);
			this->text_show_truck->TabIndex = 34;
			this->text_show_truck->Visible = false;
			// 
			// change_tr
			// 
			this->change_tr->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->change_tr->Location = System::Drawing::Point(616, 206);
			this->change_tr->Name = L"change_tr";
			this->change_tr->Size = System::Drawing::Size(187, 35);
			this->change_tr->TabIndex = 35;
			this->change_tr->Text = L"�������� ����";
			this->change_tr->UseVisualStyleBackColor = true;
			this->change_tr->Visible = false;
			this->change_tr->Click += gcnew System::EventHandler(this, &main_window::change_tr_Click);
			// 
			// back_trip2
			// 
			this->back_trip2->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_trip2->Location = System::Drawing::Point(661, 534);
			this->back_trip2->Name = L"back_trip2";
			this->back_trip2->Size = System::Drawing::Size(124, 57);
			this->back_trip2->TabIndex = 36;
			this->back_trip2->Text = L"�����";
			this->back_trip2->UseVisualStyleBackColor = true;
			this->back_trip2->Visible = false;
			this->back_trip2->Click += gcnew System::EventHandler(this, &main_window::back_trip2_Click);
			// 
			// show_trip_all
			// 
			this->show_trip_all->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->show_trip_all->Location = System::Drawing::Point(613, 67);
			this->show_trip_all->Name = L"show_trip_all";
			this->show_trip_all->Size = System::Drawing::Size(190, 70);
			this->show_trip_all->TabIndex = 37;
			this->show_trip_all->Text = L"��������";
			this->show_trip_all->UseVisualStyleBackColor = true;
			this->show_trip_all->Visible = false;
			this->show_trip_all->Click += gcnew System::EventHandler(this, &main_window::show_trip_all_Click);
			// 
			// text_show_data1
			// 
			this->text_show_data1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_show_data1->Location = System::Drawing::Point(383, 195);
			this->text_show_data1->Name = L"text_show_data1";
			this->text_show_data1->ReadOnly = true;
			this->text_show_data1->Size = System::Drawing::Size(223, 32);
			this->text_show_data1->TabIndex = 38;
			this->text_show_data1->Visible = false;
			// 
			// change_show1
			// 
			this->change_show1->AutoSize = true;
			this->change_show1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->change_show1->Location = System::Drawing::Point(643, 205);
			this->change_show1->Name = L"change_show1";
			this->change_show1->Size = System::Drawing::Size(106, 25);
			this->change_show1->TabIndex = 39;
			this->change_show1->Text = L"��������";
			this->change_show1->UseVisualStyleBackColor = true;
			this->change_show1->Visible = false;
			this->change_show1->CheckedChanged += gcnew System::EventHandler(this, &main_window::change_show1_CheckedChanged);
			// 
			// text_show_data2
			// 
			this->text_show_data2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_show_data2->Location = System::Drawing::Point(384, 233);
			this->text_show_data2->Name = L"text_show_data2";
			this->text_show_data2->ReadOnly = true;
			this->text_show_data2->Size = System::Drawing::Size(223, 32);
			this->text_show_data2->TabIndex = 40;
			this->text_show_data2->Visible = false;
			// 
			// change_show2
			// 
			this->change_show2->AutoSize = true;
			this->change_show2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->change_show2->Location = System::Drawing::Point(643, 245);
			this->change_show2->Name = L"change_show2";
			this->change_show2->Size = System::Drawing::Size(106, 25);
			this->change_show2->TabIndex = 41;
			this->change_show2->Text = L"��������";
			this->change_show2->UseVisualStyleBackColor = true;
			this->change_show2->Visible = false;
			this->change_show2->CheckedChanged += gcnew System::EventHandler(this, &main_window::change_show2_CheckedChanged);
			// 
			// text_show_data3
			// 
			this->text_show_data3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_show_data3->Location = System::Drawing::Point(383, 384);
			this->text_show_data3->Name = L"text_show_data3";
			this->text_show_data3->ReadOnly = true;
			this->text_show_data3->Size = System::Drawing::Size(223, 32);
			this->text_show_data3->TabIndex = 42;
			this->text_show_data3->Visible = false;
			// 
			// change_show3
			// 
			this->change_show3->AutoSize = true;
			this->change_show3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->change_show3->Location = System::Drawing::Point(643, 390);
			this->change_show3->Name = L"change_show3";
			this->change_show3->Size = System::Drawing::Size(106, 25);
			this->change_show3->TabIndex = 43;
			this->change_show3->Text = L"��������";
			this->change_show3->UseVisualStyleBackColor = true;
			this->change_show3->Visible = false;
			this->change_show3->CheckedChanged += gcnew System::EventHandler(this, &main_window::change_show3_CheckedChanged);
			// 
			// back_show_trip
			// 
			this->back_show_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_show_trip->Location = System::Drawing::Point(661, 532);
			this->back_show_trip->Name = L"back_show_trip";
			this->back_show_trip->Size = System::Drawing::Size(124, 57);
			this->back_show_trip->TabIndex = 44;
			this->back_show_trip->Text = L"��������� � �����";
			this->back_show_trip->UseVisualStyleBackColor = true;
			this->back_show_trip->Visible = false;
			this->back_show_trip->Click += gcnew System::EventHandler(this, &main_window::back_show_trip_Click);
			// 
			// del_trip
			// 
			this->del_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->del_trip->Location = System::Drawing::Point(616, 291);
			this->del_trip->Name = L"del_trip";
			this->del_trip->Size = System::Drawing::Size(187, 35);
			this->del_trip->TabIndex = 45;
			this->del_trip->Text = L"�������";
			this->del_trip->UseVisualStyleBackColor = true;
			this->del_trip->Visible = false;
			this->del_trip->Click += gcnew System::EventHandler(this, &main_window::del_trip_Click);
			// 
			// cancel_add_trip
			// 
			this->cancel_add_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->cancel_add_trip->Location = System::Drawing::Point(660, 471);
			this->cancel_add_trip->Name = L"cancel_add_trip";
			this->cancel_add_trip->Size = System::Drawing::Size(124, 57);
			this->cancel_add_trip->TabIndex = 46;
			this->cancel_add_trip->Text = L"������";
			this->cancel_add_trip->UseVisualStyleBackColor = true;
			this->cancel_add_trip->Visible = false;
			this->cancel_add_trip->Click += gcnew System::EventHandler(this, &main_window::cancel_add_trip_Click);
			// 
			// cancel_change_trip
			// 
			this->cancel_change_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->cancel_change_trip->Location = System::Drawing::Point(660, 471);
			this->cancel_change_trip->Name = L"cancel_change_trip";
			this->cancel_change_trip->Size = System::Drawing::Size(124, 57);
			this->cancel_change_trip->TabIndex = 47;
			this->cancel_change_trip->Text = L"������";
			this->cancel_change_trip->UseVisualStyleBackColor = true;
			this->cancel_change_trip->Visible = false;
			this->cancel_change_trip->Click += gcnew System::EventHandler(this, &main_window::cancel_change_trip_Click);
			// 
			// lab_ad_ex1
			// 
			this->lab_ad_ex1->AutoSize = true;
			this->lab_ad_ex1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_ad_ex1->Location = System::Drawing::Point(36, 268);
			this->lab_ad_ex1->Name = L"lab_ad_ex1";
			this->lab_ad_ex1->Size = System::Drawing::Size(92, 23);
			this->lab_ad_ex1->TabIndex = 51;
			this->lab_ad_ex1->Text = L"�����:";
			this->lab_ad_ex1->Visible = false;
			// 
			// lab_ad_ex2
			// 
			this->lab_ad_ex2->AutoSize = true;
			this->lab_ad_ex2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lab_ad_ex2->Location = System::Drawing::Point(35, 336);
			this->lab_ad_ex2->Name = L"lab_ad_ex2";
			this->lab_ad_ex2->Size = System::Drawing::Size(66, 23);
			this->lab_ad_ex2->TabIndex = 52;
			this->lab_ad_ex2->Text = L"����:";
			this->lab_ad_ex2->Visible = false;
			// 
			// text_ad_ex1
			// 
			this->text_ad_ex1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad_ex1->Location = System::Drawing::Point(321, 263);
			this->text_ad_ex1->Name = L"text_ad_ex1";
			this->text_ad_ex1->Size = System::Drawing::Size(218, 32);
			this->text_ad_ex1->TabIndex = 53;
			this->text_ad_ex1->Visible = false;
			// 
			// text_ad_ex2
			// 
			this->text_ad_ex2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_ad_ex2->Location = System::Drawing::Point(321, 336);
			this->text_ad_ex2->MinDate = System::DateTime(2000, 1, 1, 0, 0, 0, 0);
			this->text_ad_ex2->Name = L"text_ad_ex2";
			this->text_ad_ex2->Size = System::Drawing::Size(219, 32);
			this->text_ad_ex2->TabIndex = 54;
			this->text_ad_ex2->Visible = false;
			// 
			// cancel_ad_ex
			// 
			this->cancel_ad_ex->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->cancel_ad_ex->Location = System::Drawing::Point(661, 471);
			this->cancel_ad_ex->Name = L"cancel_ad_ex";
			this->cancel_ad_ex->Size = System::Drawing::Size(124, 57);
			this->cancel_ad_ex->TabIndex = 55;
			this->cancel_ad_ex->Text = L"������";
			this->cancel_ad_ex->UseVisualStyleBackColor = true;
			this->cancel_ad_ex->Visible = false;
			this->cancel_ad_ex->Click += gcnew System::EventHandler(this, &main_window::cancel_ad_ex_Click);
			// 
			// back_ex
			// 
			this->back_ex->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_ex->Location = System::Drawing::Point(661, 534);
			this->back_ex->Name = L"back_ex";
			this->back_ex->Size = System::Drawing::Size(124, 57);
			this->back_ex->TabIndex = 56;
			this->back_ex->Text = L"��������� � �����";
			this->back_ex->UseVisualStyleBackColor = true;
			this->back_ex->Visible = false;
			this->back_ex->Click += gcnew System::EventHandler(this, &main_window::back_ex_Click);
			// 
			// text_show_allex
			// 
			this->text_show_allex->Font = (gcnew System::Drawing::Font(L"Century Gothic", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->text_show_allex->Location = System::Drawing::Point(12, 78);
			this->text_show_allex->Multiline = true;
			this->text_show_allex->Name = L"text_show_allex";
			this->text_show_allex->ReadOnly = true;
			this->text_show_allex->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->text_show_allex->Size = System::Drawing::Size(483, 513);
			this->text_show_allex->TabIndex = 57;
			this->text_show_allex->Visible = false;
			// 
			// back_ex2
			// 
			this->back_ex2->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->back_ex2->Location = System::Drawing::Point(663, 535);
			this->back_ex2->Name = L"back_ex2";
			this->back_ex2->Size = System::Drawing::Size(121, 56);
			this->back_ex2->TabIndex = 58;
			this->back_ex2->Text = L"�����";
			this->back_ex2->UseVisualStyleBackColor = true;
			this->back_ex2->Visible = false;
			this->back_ex2->Click += gcnew System::EventHandler(this, &main_window::back_ex2_Click);
			// 
			// del_ex
			// 
			this->del_ex->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->del_ex->Location = System::Drawing::Point(553, 295);
			this->del_ex->Name = L"del_ex";
			this->del_ex->Size = System::Drawing::Size(187, 35);
			this->del_ex->TabIndex = 59;
			this->del_ex->Text = L"�������";
			this->del_ex->UseVisualStyleBackColor = true;
			this->del_ex->Visible = false;
			this->del_ex->Click += gcnew System::EventHandler(this, &main_window::del_ex_Click);
			// 
			// text_del_ex
			// 
			this->text_del_ex->Location = System::Drawing::Point(743, 246);
			this->text_del_ex->Name = L"text_del_ex";
			this->text_del_ex->Size = System::Drawing::Size(55, 20);
			this->text_del_ex->TabIndex = 61;
			this->text_del_ex->Visible = false;
			// 
			// lab_del_ex
			// 
			this->lab_del_ex->AutoSize = true;
			this->lab_del_ex->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_del_ex->Location = System::Drawing::Point(496, 244);
			this->lab_del_ex->Name = L"lab_del_ex";
			this->lab_del_ex->Size = System::Drawing::Size(242, 21);
			this->lab_del_ex->TabIndex = 62;
			this->lab_del_ex->Text = L"����� ���������� �������:";
			this->lab_del_ex->Visible = false;
			// 
			// choise_exp1
			// 
			this->choise_exp1->AutoSize = true;
			this->choise_exp1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->choise_exp1->Location = System::Drawing::Point(57, 109);
			this->choise_exp1->Name = L"choise_exp1";
			this->choise_exp1->Size = System::Drawing::Size(70, 27);
			this->choise_exp1->TabIndex = 63;
			this->choise_exp1->TabStop = true;
			this->choise_exp1->Text = L"���";
			this->choise_exp1->UseVisualStyleBackColor = true;
			this->choise_exp1->Visible = false;
			// 
			// choise_exp2
			// 
			this->choise_exp2->AutoSize = true;
			this->choise_exp2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->choise_exp2->Location = System::Drawing::Point(297, 107);
			this->choise_exp2->Name = L"choise_exp2";
			this->choise_exp2->Size = System::Drawing::Size(198, 27);
			this->choise_exp2->TabIndex = 64;
			this->choise_exp2->TabStop = true;
			this->choise_exp2->Text = L"������ � ������";
			this->choise_exp2->UseVisualStyleBackColor = true;
			this->choise_exp2->Visible = false;
			// 
			// choise_exp3
			// 
			this->choise_exp3->AutoSize = true;
			this->choise_exp3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->choise_exp3->Location = System::Drawing::Point(616, 110);
			this->choise_exp3->Name = L"choise_exp3";
			this->choise_exp3->Size = System::Drawing::Size(119, 27);
			this->choise_exp3->TabIndex = 65;
			this->choise_exp3->TabStop = true;
			this->choise_exp3->Text = L"������";
			this->choise_exp3->UseVisualStyleBackColor = true;
			this->choise_exp3->Visible = false;
			// 
			// but_good1
			// 
			this->but_good1->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_good1->Location = System::Drawing::Point(282, 367);
			this->but_good1->Name = L"but_good1";
			this->but_good1->Size = System::Drawing::Size(190, 70);
			this->but_good1->TabIndex = 66;
			this->but_good1->Text = L"������!";
			this->but_good1->UseVisualStyleBackColor = true;
			this->but_good1->Visible = false;
			this->but_good1->Click += gcnew System::EventHandler(this, &main_window::but_good1_Click);
			// 
			// arc_but
			// 
			this->arc_but->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->arc_but->Location = System::Drawing::Point(300, 434);
			this->arc_but->Name = L"arc_but";
			this->arc_but->Size = System::Drawing::Size(190, 70);
			this->arc_but->TabIndex = 67;
			this->arc_but->Text = L"�����";
			this->arc_but->UseVisualStyleBackColor = true;
			this->arc_but->Click += gcnew System::EventHandler(this, &main_window::arc_but_Click);
			// 
			// cho_year
			// 
			this->cho_year->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->cho_year->Location = System::Drawing::Point(496, 240);
			this->cho_year->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {3000, 0, 0, 0});
			this->cho_year->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {2000, 0, 0, 0});
			this->cho_year->Name = L"cho_year";
			this->cho_year->Size = System::Drawing::Size(100, 32);
			this->cho_year->TabIndex = 69;
			this->cho_year->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {2017, 0, 0, 0});
			this->cho_year->Visible = false;
			// 
			// lab_arc1
			// 
			this->lab_arc1->AutoSize = true;
			this->lab_arc1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_arc1->Location = System::Drawing::Point(122, 195);
			this->lab_arc1->Name = L"lab_arc1";
			this->lab_arc1->Size = System::Drawing::Size(269, 23);
			this->lab_arc1->TabIndex = 70;
			this->lab_arc1->Text = L"�������� ����� (�����)";
			this->lab_arc1->Visible = false;
			// 
			// lab_arc2
			// 
			this->lab_arc2->AutoSize = true;
			this->lab_arc2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->lab_arc2->Location = System::Drawing::Point(492, 192);
			this->lab_arc2->Name = L"lab_arc2";
			this->lab_arc2->Size = System::Drawing::Size(145, 23);
			this->lab_arc2->TabIndex = 71;
			this->lab_arc2->Text = L"�������� ���";
			this->lab_arc2->Visible = false;
			// 
			// but_arc1
			// 
			this->but_arc1->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_arc1->Location = System::Drawing::Point(282, 409);
			this->but_arc1->Name = L"but_arc1";
			this->but_arc1->Size = System::Drawing::Size(190, 70);
			this->but_arc1->TabIndex = 72;
			this->but_arc1->Text = L"�������";
			this->but_arc1->UseVisualStyleBackColor = true;
			this->but_arc1->Visible = false;
			this->but_arc1->Click += gcnew System::EventHandler(this, &main_window::but_arc1_Click);
			// 
			// but_arc_back
			// 
			this->but_arc_back->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_arc_back->Location = System::Drawing::Point(661, 534);
			this->but_arc_back->Name = L"but_arc_back";
			this->but_arc_back->Size = System::Drawing::Size(124, 57);
			this->but_arc_back->TabIndex = 73;
			this->but_arc_back->Text = L"�����";
			this->but_arc_back->UseVisualStyleBackColor = true;
			this->but_arc_back->Visible = false;
			this->but_arc_back->Click += gcnew System::EventHandler(this, &main_window::but_arc_back_Click);
			// 
			// but_arc_trip
			// 
			this->but_arc_trip->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_arc_trip->Location = System::Drawing::Point(300, 154);
			this->but_arc_trip->Name = L"but_arc_trip";
			this->but_arc_trip->Size = System::Drawing::Size(190, 70);
			this->but_arc_trip->TabIndex = 74;
			this->but_arc_trip->Text = L"�������� ���������� � ������";
			this->but_arc_trip->UseVisualStyleBackColor = true;
			this->but_arc_trip->Visible = false;
			this->but_arc_trip->Click += gcnew System::EventHandler(this, &main_window::but_arc_trip_Click);
			// 
			// cho_mo
			// 
			this->cho_mo->Font = (gcnew System::Drawing::Font(L"Century Gothic", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->cho_mo->Location = System::Drawing::Point(136, 240);
			this->cho_mo->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {12, 0, 0, 0});
			this->cho_mo->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			this->cho_mo->Name = L"cho_mo";
			this->cho_mo->Size = System::Drawing::Size(100, 32);
			this->cho_mo->TabIndex = 75;
			this->cho_mo->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			this->cho_mo->Visible = false;
			// 
			// lab_main
			// 
			this->lab_main->AutoSize = true;
			this->lab_main->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 29.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lab_main->Location = System::Drawing::Point(18, 16);
			this->lab_main->Name = L"lab_main";
			this->lab_main->Size = System::Drawing::Size(747, 42);
			this->lab_main->TabIndex = 78;
			this->lab_main->Text = L"���������� �ר� ��������������";
			// 
			// but_arc_exp
			// 
			this->but_arc_exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_arc_exp->Location = System::Drawing::Point(300, 245);
			this->but_arc_exp->Name = L"but_arc_exp";
			this->but_arc_exp->Size = System::Drawing::Size(190, 70);
			this->but_arc_exp->TabIndex = 79;
			this->but_arc_exp->Text = L"�������� ���������� � ��������";
			this->but_arc_exp->UseVisualStyleBackColor = true;
			this->but_arc_exp->Visible = false;
			this->but_arc_exp->Click += gcnew System::EventHandler(this, &main_window::but_arc_exp_Click);
			// 
			// but_form_exp
			// 
			this->but_form_exp->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_form_exp->Location = System::Drawing::Point(300, 434);
			this->but_form_exp->Name = L"but_form_exp";
			this->but_form_exp->Size = System::Drawing::Size(190, 70);
			this->but_form_exp->TabIndex = 80;
			this->but_form_exp->Text = L"������������ ����� � ��������";
			this->but_form_exp->UseVisualStyleBackColor = true;
			this->but_form_exp->Visible = false;
			this->but_form_exp->Click += gcnew System::EventHandler(this, &main_window::but_form_exp_Click);
			// 
			// but_back_main
			// 
			this->but_back_main->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_back_main->Location = System::Drawing::Point(660, 534);
			this->but_back_main->Name = L"but_back_main";
			this->but_back_main->Size = System::Drawing::Size(124, 57);
			this->but_back_main->TabIndex = 81;
			this->but_back_main->Text = L"�����";
			this->but_back_main->UseVisualStyleBackColor = true;
			this->but_back_main->Visible = false;
			this->but_back_main->Click += gcnew System::EventHandler(this, &main_window::but_back_main_Click);
			// 
			// but_back_arc
			// 
			this->but_back_arc->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->but_back_arc->Location = System::Drawing::Point(661, 534);
			this->but_back_arc->Name = L"but_back_arc";
			this->but_back_arc->Size = System::Drawing::Size(124, 57);
			this->but_back_arc->TabIndex = 82;
			this->but_back_arc->Text = L"�����";
			this->but_back_arc->UseVisualStyleBackColor = true;
			this->but_back_arc->Visible = false;
			this->but_back_arc->Click += gcnew System::EventHandler(this, &main_window::but_back_arc_Click);
			// 
			// main_window
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(806, 601);
			this->ControlBox = false;
			this->Controls->Add(this->but_back_arc);
			this->Controls->Add(this->but_back_main);
			this->Controls->Add(this->but_form_exp);
			this->Controls->Add(this->but_arc_exp);
			this->Controls->Add(this->but_arc_trip);
			this->Controls->Add(this->lab_main);
			this->Controls->Add(this->cho_mo);
			this->Controls->Add(this->but_arc_back);
			this->Controls->Add(this->but_arc1);
			this->Controls->Add(this->lab_arc2);
			this->Controls->Add(this->lab_arc1);
			this->Controls->Add(this->cho_year);
			this->Controls->Add(this->arc_but);
			this->Controls->Add(this->choise_exp3);
			this->Controls->Add(this->choise_exp2);
			this->Controls->Add(this->choise_exp1);
			this->Controls->Add(this->lab_del_ex);
			this->Controls->Add(this->text_del_ex);
			this->Controls->Add(this->del_ex);
			this->Controls->Add(this->back_ex2);
			this->Controls->Add(this->text_show_allex);
			this->Controls->Add(this->back_ex);
			this->Controls->Add(this->cancel_ad_ex);
			this->Controls->Add(this->text_ad_ex2);
			this->Controls->Add(this->text_ad_ex1);
			this->Controls->Add(this->lab_ad_ex2);
			this->Controls->Add(this->lab_ad_ex1);
			this->Controls->Add(this->cancel_change_trip);
			this->Controls->Add(this->cancel_add_trip);
			this->Controls->Add(this->del_trip);
			this->Controls->Add(this->back_show_trip);
			this->Controls->Add(this->change_show3);
			this->Controls->Add(this->text_show_data3);
			this->Controls->Add(this->change_show2);
			this->Controls->Add(this->text_show_data2);
			this->Controls->Add(this->change_show1);
			this->Controls->Add(this->text_show_data1);
			this->Controls->Add(this->show_trip_all);
			this->Controls->Add(this->back_trip2);
			this->Controls->Add(this->change_tr);
			this->Controls->Add(this->text_show_truck);
			this->Controls->Add(this->text_rfullinfo);
			this->Controls->Add(this->rfull_info);
			this->Controls->Add(this->rshort_info);
			this->Controls->Add(this->logo);
			this->Controls->Add(this->back_main_ex);
			this->Controls->Add(this->form_report_exp);
			this->Controls->Add(this->show_exp);
			this->Controls->Add(this->add_exp);
			this->Controls->Add(this->check_1);
			this->Controls->Add(this->text_ad5);
			this->Controls->Add(this->text_ad3);
			this->Controls->Add(this->text_ad2);
			this->Controls->Add(this->back_trip);
			this->Controls->Add(this->text_ad4);
			this->Controls->Add(this->lab_ad_trip5);
			this->Controls->Add(this->lab_ad_trip4);
			this->Controls->Add(this->lab_ad_trip3);
			this->Controls->Add(this->lab_ad_trip2);
			this->Controls->Add(this->text_ad1);
			this->Controls->Add(this->lab_ad_trip1);
			this->Controls->Add(this->back_main);
			this->Controls->Add(this->show_trip);
			this->Controls->Add(this->add_trip);
			this->Controls->Add(this->exit_main);
			this->Controls->Add(this->form_report);
			this->Controls->Add(this->exp);
			this->Controls->Add(this->trip);
			this->Controls->Add(this->but_good1);
			this->MaximizeBox = false;
			this->Name = L"main_window";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"������������ �������� \"�������\"";
			this->Load += gcnew System::EventHandler(this, &main_window::main_window_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->logo))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cho_year))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->cho_mo))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		//����������� � ������� ���� � ����� �� �������� ����
private: System::Void exit_main_Click(System::Object^  sender, System::EventArgs^  e) {
				save_trucks(*vectdata1);
				save_expenses(*vectdata2);
				Environment::Exit(0);
			 }
private: System::Void back_main_Click(System::Object^  sender, System::EventArgs^  e) {
				add_trip->Visible = false;
				show_trip->Visible = false;
				back_main->Visible = false;
				trip->Visible = true;
				exp->Visible = true;
				form_report->Visible = true;
				exit_main->Visible = true;
				lab_main->Text = "���������� �ר� ��������������";
				logo->Visible = true;
				arc_but->Visible = true;
		 }
		 //�������� ������������ ������
private: System::Void main_window_Load(System::Object^  sender, System::EventArgs^  e) {
					load_expenses_from_file(*vectdata2,"");
			        load_trucks_from_file(*vectdata1,"");	
					vectcheck = new vector<Truck*>();
					bool yes = check_all_trucks(*vectdata1, *vectcheck);
					if(yes)
					{
						Form^ f = gcnew check_today(vectcheck);
						f->ShowDialog();
					}
					delete vectcheck;
					vectcheck = nullptr;
		 }

		//�����
private: System::Void trip_Click(System::Object^  sender, System::EventArgs^  e){
				 trip->Visible = false;
				 exp->Visible = false;
				 form_report->Visible = false;
				 exit_main->Visible = false;
				 lab_main->Text = "�����";
				 add_trip->Visible = true;
				 show_trip->Visible = true;
				 back_main->Visible = true;
				 logo->Visible = false;
				 arc_but->Visible = false;
			 }

		//���, ��� ������� � �������
private: System::Void add_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_trip->Visible = false;
			 show_trip->Visible = false;
			 back_main->Visible = false;
			 lab_main->Text = "����� ����";
			 lab_ad_trip1->Visible = true;
			 lab_ad_trip2->Visible = true;
			 lab_ad_trip3->Visible = true;
			 lab_ad_trip4->Visible = true;
			 text_ad1->Visible = true;
			 text_ad2->Visible = true;
			 text_ad3->Visible = true;
			 text_ad4->Visible = true;
			 back_trip->Visible = true;
	         check_b1 = false;
			 check_1->Visible = true;
			 cancel_add_trip->Visible = true;
		 }
private: System::Void back_trip_Click(System::Object^  sender, System::EventArgs^  e) { 
			 if(text_ad1->Text == "")
			 {
				 Form^ f = gcnew prevent(1);
				 f->ShowDialog();
				 return;
			 }
			 if(text_ad4->Text == "")
			 {
				 Form^ f = gcnew prevent(2);
				 f->ShowDialog();
				 return;
			 }	 
			 string temp;
			 MarshalString(text_ad4->Text,temp);
			 if(!all_of(temp.begin(), temp.end(), unPred()))
			 {
			  	 Form^ f = gcnew prevent(11);
				 f->ShowDialog();
				 text_ad4->Text = "";
				 return;
			 }
			 if( System::Int32::Parse(text_ad4->Text) <=0)
			 {
				 Form^ f = gcnew prevent(10);
				 f->ShowDialog();
				 text_ad4->Text = "";
				 return;
			 }
			 
			 data1 = new Truck();
			 data1->_truck_day->tm_year = text_ad2->Value.Year;
			 data1->_truck_day->tm_mon = (text_ad2->Value.Month)-1;
			 data1->_truck_day->tm_mday = text_ad2->Value.Day;
			 data1->_account_day->tm_year = text_ad3->Value.Year;
			 data1->_account_day->tm_mon = (text_ad3->Value.Month)-1;
			 data1->_account_day->tm_mday = text_ad3->Value.Day;
			 if (compareDate(data1->_truck_day, data1->_account_day) < 0)
			 {
				 Form^ f = gcnew prevent(3);
				 f->ShowDialog();
				 delete data1;
				 return;
			 }
			 if(check_b1)
			 {
				data1->_fee_day->tm_year = text_ad5->Value.Year;
				data1->_fee_day->tm_mon = (text_ad5->Value.Month)-1;
				data1->_fee_day->tm_mday = text_ad5->Value.Day;
				data1->_got_fee = true;
				if (compareDate(data1->_account_day, data1->_fee_day) < 0)
				{
					Form^ f = gcnew prevent(4);
					f->ShowDialog();
					delete data1;
					return;
				}
			 }
			 string temp1;
			 MarshalString(text_ad1->Text, temp1);
			 data1->change_descr(temp1);
			 data1->_fee = Convert::ToDouble(text_ad4->Text);
			 ElAddTruck(data1);
			 data1 = nullptr;

			 lab_main->Text = "�����";
			 check_1->Visible = false;
			 check_b1 = false;
			 text_ad1->Text = "";
			 text_ad2->Checked = false;
			 text_ad3->Checked = false;
			 text_ad4->Text = "";
			 text_ad5->Checked = false;
			 cancel_add_trip->Visible = false;
			 check_1->Visible = false;
			 check_1->Checked = false;
			 check_1->Visible = false; 
			 text_ad5->Visible = false; 
			 lab_ad_trip5->Visible = false;
			 lab_ad_trip1->Visible = false;
			 lab_ad_trip2->Visible = false;
			 lab_ad_trip3->Visible = false;
			 lab_ad_trip4->Visible = false;
			 lab_ad_trip5->Visible = false;
			 text_ad1->Visible = false;
			 text_ad2->Visible = false;
			 text_ad3->Visible = false;
			 text_ad4->Visible = false;
			 text_ad5->Visible = false;
			 back_trip->Visible = false;
			 add_trip->Visible = true;
			 show_trip->Visible = true;
			 back_main->Visible = true;
		 }
private: System::Void cancel_add_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 lab_main->Text = "�����";
			 lab_ad_trip1->Visible = false;
			 lab_ad_trip2->Visible = false;
			 lab_ad_trip3->Visible = false;
			 lab_ad_trip4->Visible = false;
			 lab_ad_trip5->Visible = false;
			 text_ad1->Visible = false;
			 text_ad2->Visible = false;
			 text_ad3->Visible = false;
			 text_ad4->Visible = false;
			 text_ad5->Visible = false;
			 back_trip->Visible = false;
			 add_trip->Visible = true;
			 show_trip->Visible = true;
			 back_main->Visible = true;
			 text_ad1->Text = "";
			 text_ad2->Checked = false;
			 text_ad3->Checked = false;
			 text_ad4->Text = "";
			 text_ad5->Checked = false;
			 cancel_add_trip->Visible = false;
			 check_1->Visible = false;
			 check_1->Checked = false;
		 }
private: System::Void check_1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 check_b1 = !check_b1;
			 if(check_b1)
			 {
				lab_ad_trip5->Visible = true;
				text_ad5->Visible = true;
			 }
			 if(!check_b1)
			 {
				lab_ad_trip5->Visible = false;
				text_ad5->Visible = false;
			 }
		 }



private: System::Void show_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_trip->Visible = false;
			 show_trip->Visible = false;
			 back_main->Visible = false;
			 lab_main->Text = "��������";
			 rshort_info->Visible = true;
			 rfull_info->Visible = true;
			 text_rfullinfo->Visible = true;
			 text_show_truck->Visible = true;
			 show_trip_all->Visible = true;
			 back_trip2->Visible = true;
		 }
private: System::Void back_trip2_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_trip->Visible = true;
			 show_trip->Visible = true;
			 back_main->Visible = true;
			 lab_main->Text = "�����";
			 rshort_info->Visible = false;
			 rfull_info->Visible = false;
			 text_rfullinfo->Visible = false;
			 text_show_truck->Text = "";
			 text_show_truck->Visible = false;
			 show_trip_all->Visible = false;
			 change_tr->Visible = false;
			 back_trip2->Visible = false;
			 del_trip->Visible = false;
		 }
private: System::Void rfull_info_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 text_rfullinfo->ReadOnly = false;
			 check_b2 = true;
		 }
private: System::Void rshort_info_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 text_rfullinfo->ReadOnly = true;
			 check_b2 = false;
		 }
private: System::Void show_trip_all_Click(System::Object^  sender, System::EventArgs^  e) {
			 String^ of = "";
			 if(!check_b2)
			 { 
				 for (int i = 0; i < (*vectdata1).size(); ++i) {
					 of += (i+1).ToString() + ". " + gcnew System::String((*vectdata1)[i]->_descr.c_str()) +
					"; " + str_date((*vectdata1)[i]->_truck_day) + "\r\n";
				 }
				 change_tr->Visible = false;
				 del_trip->Visible = false;
			}
			 if(check_b2)
			 {
				 if(text_rfullinfo->Text == "")
				 {
					 Form^ f = gcnew prevent(12);
					 f->ShowDialog();
					 return;
				 }	 
				 string temp1;
				 MarshalString(text_rfullinfo->Text,temp1);
				 if(!all_of(temp1.begin(), temp1.end(), unPred()))
				 {
					 Form^ f = gcnew prevent(12);
					 f->ShowDialog();
					 text_rfullinfo->Text = "";
					 return;
				 }
				 int j = System::Int32::Parse(text_rfullinfo->Text);
				 if( j <=0 || j > vectdata1->size())
				 {
					 Form^ f = gcnew prevent(5);
					 f->ShowDialog();
					 text_rfullinfo->Text = "";
					 return;
				 }
				
				 data1 = (*vectdata1)[j-1];
				 of+=gcnew System::String(data1->_descr.c_str())+"\r\n���� �����: " + 
			     str_date(data1->_truck_day) + "\r\n���� ������� �����: " + str_date(data1->_account_day)+
				 "\r\n������ �������: " + (data1->_fee).ToString() +"�.\r\n";
				 if(data1->_got_fee)
					 of+="���� ��������� �������: " + str_date(data1->_fee_day);
				 else
				 {
					 tm * d = data1->presumeDate();
					 of+="����������������� ���� ��������� �������: " + str_date(d);
					 delete d;
				 }
				 change_tr->Visible = true;
				 del_trip->Visible = true;
			 }
			 data1 = nullptr;
			 text_show_truck->Text = of;
}
private: System::Void change_show1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			chn1 = !chn1;
			if(chn1)
			{
				text_show_data1->Visible = false;
				text_ad2->Visible = true;
			}
			if(!chn1)
			{
				text_show_data1->Visible = true;
				text_ad2->Visible = false;
			}
		 }
private: System::Void change_tr_Click(System::Object^  sender, System::EventArgs^  e) {
			 chn1 = false;
			 chn2 = false;
			 chn3 = false;
			 check_b1 = false;
			 change_show1->Checked = false;
			 change_show2->Checked = false;
			 change_show3->Checked = false;
			 lab_main->Text = "��������� �����";
			 del_trip->Visible = false;
			 rshort_info->Visible = false;
			 rfull_info->Visible = false;
			 text_rfullinfo->Visible = false;
			 text_show_truck->Visible = false;
			 show_trip_all->Visible = false;
			 change_tr->Visible = false;
			 back_trip2->Visible = false;
			 lab_ad_trip1->Visible = true;
			 back_show_trip->Visible = true;
			 lab_ad_trip2->Visible = true;
			 lab_ad_trip3->Visible = true;
			 lab_ad_trip4->Visible = true;
			 text_show_data1->Visible = true;
			 text_show_data2->Visible = true;
			 change_show1->Visible = true;
			 change_show2->Visible = true;
			 text_ad1->Visible = true;
			 text_ad4->Visible = true;
			 int j = System::Int32::Parse(text_rfullinfo->Text);
			 data1 = (*vectdata1)[j-1];
			 text_ad1->Text = gcnew System::String(data1->_descr.c_str());
			 text_show_data1->Text = str_date(data1->_truck_day);
			 text_show_data2->Text = str_date(data1->_account_day);
			 text_ad4->Text = (data1->_fee).ToString();
			 text_ad2->Visible = false;
			 text_ad3->Visible = false;
			 text_ad5->Visible = false;
			 lab_ad_trip5->Visible = true;
			 text_show_data3->Visible = true;
			 change_show3->Visible = true;
			 check_b1 = data1->_got_fee;
			 if(!check_b1)
				 text_show_data3->Text = "�� ��������";
			 if(check_b1)
				 text_show_data3->Text = str_date(data1->_fee_day);
			 cancel_change_trip->Visible = true;
		 }
private: System::Void back_show_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(text_ad1->Text == "")
			 {
				 Form^ f = gcnew prevent(1);
				 f->ShowDialog();
				 return;
			 }
			 if(text_ad4->Text == "")
			 {
				 Form^ f = gcnew prevent(2);
				 f->ShowDialog();
				 return;
			 }	 
			 string temp;
			 MarshalString(text_ad4->Text,temp);
			 if(!all_of(temp.begin(), temp.end(), unPred()))
			 {
			  	 Form^ f = gcnew prevent(11);
				 f->ShowDialog();
				 text_ad4->Text = "";
				 return;
			 }
			 if( System::Int32::Parse(text_ad4->Text) <=0)
			 {
				 Form^ f = gcnew prevent(10);
				 f->ShowDialog();
				 text_ad4->Text = "";
				 return;
			 }
			 if(chn1)
			 {
				data1->_truck_day->tm_year = text_ad2->Value.Year;
				data1->_truck_day->tm_mon = (text_ad2->Value.Month)-1;
				data1->_truck_day->tm_mday = text_ad2->Value.Day;
			 }
			 if(chn2)
			 {
				data1->_account_day->tm_year = text_ad2->Value.Year;
				data1->_account_day->tm_mon = (text_ad2->Value.Month)-1;
				data1->_account_day->tm_mday = text_ad2->Value.Day;
				if (compareDate(data1->_truck_day, data1->_account_day) < 0)
				{
					 Form^ f = gcnew prevent(3);
					 f->ShowDialog();
					 delete data1;
					 return;
				 }
			 }
			 if(chn3)          
			 {
				data1->_fee_day->tm_year = text_ad5->Value.Year;
				data1->_fee_day->tm_mon = (text_ad5->Value.Month)-1;
				data1->_fee_day->tm_mday = text_ad5->Value.Day;
				data1->_got_fee = true;
				if (compareDate(data1->_account_day, data1->_fee_day) < 0)
				{
					Form^ f = gcnew prevent(4);
					f->ShowDialog();
					delete data1;
					return;
				}
			 }
			 string temp1;
			 MarshalString(text_ad1->Text, temp1);
			 data1->change_descr(temp1);
			 data1->_fee = Convert::ToDouble(text_ad4->Text);

			 lab_main->Text = "��������";
			 rshort_info->Visible = true;
			 rfull_info->Visible = true;
			 text_rfullinfo->Visible = true;
			 text_show_truck->Visible = true;
			 show_trip_all->Visible = true;
			 change_tr->Visible = true;
			 back_trip2->Visible = true;
			 lab_ad_trip1->Visible = false;
			 back_show_trip->Visible = false;
			 text_ad1->Visible = false;
			 text_ad1->Text = "";
			 lab_ad_trip2->Visible = false;
			 text_show_data1->Visible = false;
			 change_show1->Visible = false;
			 text_ad2->Visible = false;
			 lab_ad_trip3->Visible = false;
			 text_show_data2->Visible = false;
			 text_ad3->Visible = false;
			 change_show2->Visible = false;
			 lab_ad_trip4->Visible = false;
			 text_show_data3->Visible = false;
			 text_ad4->Visible = false;
			 text_ad4->Text = "";
			 lab_ad_trip5->Visible = false;
			 text_show_data3->Visible = false;
			 change_show3->Visible = false;
			 text_ad5->Visible = false;
			 
			 String^ of = "";
			 int j = System::Int32::Parse(text_rfullinfo->Text);
			 data1 = (*vectdata1)[j-1];
			 of+=gcnew System::String(data1->_descr.c_str())+"\r\n���� �����: " + 
			 str_date(data1->_truck_day) + "\r\n���� ������� �����: " + str_date(data1->_account_day)+
			 "\r\n������ �������: " + (data1->_fee).ToString() +"�.\r\n";
			 if(data1->_got_fee)
				of+="���� ��������� �������: " + str_date(data1->_fee_day);
			 else
			 {
				 tm * d = data1->presumeDate();
				 of+="����������������� ���� ��������� �������: " + str_date(d);
				 delete d;
			 }
			 data1 = nullptr;
			 text_show_truck->Text = of;		
			 cancel_change_trip->Visible = false;
		 }
private: System::Void change_show2_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			chn2 = !chn2;
			if(chn2)
			{
				text_show_data2->Visible = false;
				text_ad3->Visible = true;
			}
			if(!chn2)
			{
				text_show_data2->Visible = true;
				text_ad3->Visible = false;
			}
		 }
private: System::Void change_show3_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			chn3 = !chn3;
			if(chn3)
			{
				text_show_data3->Visible = false;
				text_ad5->Visible = true;
			}
			if(!chn3)
			{
				text_show_data3->Visible = true;
				text_ad5->Visible = false;
			}
		 }
private: System::Void del_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(text_rfullinfo->Text == "")
			 {
				 Form^ f1 = gcnew prevent(6);
				 f1->ShowDialog();
				 return;
			 }
			 string temp1;
			 MarshalString(text_rfullinfo->Text,temp1);
			 if(!all_of(temp1.begin(), temp1.end(), unPred()))
			 {
				 Form^ f1 = gcnew prevent(12);
				 f1->ShowDialog();
				 text_rfullinfo->Text = "";
				 return;
			 }
			 int j = System::Int32::Parse(text_rfullinfo->Text) - 1;

			 if(j < 0 || j > vectdata1->size())
			 {
				 Form^ f1 = gcnew prevent(5);
				 f1->ShowDialog();
				 text_rfullinfo->Text = "";
				 return;
			 }
			 Form^ f = gcnew del(vectdata1, j);
			 f->ShowDialog();
			 data1 = nullptr;
			 text_rfullinfo->Text = "";
			 text_show_truck->Text = "";
			 del_trip->Visible = false;
			 change_tr->Visible = false;
		 }
private: System::Void cancel_change_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 chn1 = false;
			 chn2 = false;
			 chn3 = false;
			 check_b1 = false;
			 lab_main->Text = "��������";
			 rshort_info->Visible = true;
			 rfull_info->Visible = true;
			 text_rfullinfo->Visible = true;
			 text_show_truck->Visible = true;
			 show_trip_all->Visible = true;
			 change_tr->Visible = true;
			 back_trip2->Visible = true;
			 lab_ad_trip1->Visible = false;
			 back_show_trip->Visible = false;
			 text_ad1->Visible = false;
			 text_ad1->Text = "";
			 lab_ad_trip2->Visible = false;
			 text_show_data1->Visible = false;
			 change_show1->Visible = false;
			 text_ad2->Visible = false;
			 lab_ad_trip3->Visible = false;
			 text_show_data2->Visible = false;
			 text_ad3->Visible = false;
			 change_show2->Visible = false;
			 lab_ad_trip4->Visible = false;
			 text_show_data3->Visible = false;
			 text_ad4->Visible = false;
			 text_ad4->Text = "";
			 lab_ad_trip5->Visible = false;
			 text_show_data3->Visible = false;
			 change_show3->Visible = false;
			 text_ad5->Visible = false;
			 cancel_change_trip->Visible = false;
		 }


		//�������
private: System::Void exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 trip->Visible = false;
			 exp->Visible = false;
			 form_report->Visible = false;
			 exit_main->Visible = false;
			 lab_main->Text = "�������";
			 add_exp->Visible = true;
			 show_exp->Visible = true;
			 form_report_exp->Visible = true;
			 back_main_ex->Visible = true;
			 logo->Visible = false;
			 arc_but->Visible = false;
		 }
private: System::Void back_main_ex_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_exp->Visible = false;
			 show_exp->Visible = false;
			 back_main_ex->Visible = false;
			 form_report_exp->Visible = false;
			 trip->Visible = true;
			 exp->Visible = true;
			 form_report->Visible = true;
			 exit_main->Visible = true;
			 lab_main->Text = "���������� �ר� ��������������";
			 logo->Visible = true;
			 arc_but->Visible = true;
		 }
		
		 //��� ��� � ��������� �������
private: System::Void add_exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 lab_main->Text = "���������� �������";
			 add_exp->Visible = false;
			 show_exp->Visible = false;
			 back_main_ex->Visible = false;
			 form_report_exp->Visible = false;
			 lab_ad_ex1->Visible = true;
			 lab_ad_ex2->Visible = true;
			 choise_exp1->Visible = true;
			 choise_exp2->Visible = true;
			 choise_exp3->Visible = true;
			 text_ad_ex1->Visible = true;
			 text_ad_ex2->Visible = true;
			 cancel_ad_ex->Visible = true;
			 back_ex->Visible = true;
		 }
private: System::Void cancel_ad_ex_Click(System::Object^  sender, System::EventArgs^  e) {
			 lab_main->Text = "�������";
			 add_exp->Visible = true;
			 show_exp->Visible = true;
			 back_main_ex->Visible = true;
			 form_report_exp->Visible = true;
			 lab_ad_ex1->Visible = false;
			 lab_ad_ex2->Visible = false;
			 choise_exp1->Visible = false;
			 choise_exp2->Visible = false;
			 choise_exp3->Visible = false;
			 text_ad_ex1->Visible = false;
			 text_ad_ex2->Visible = false;
			 cancel_ad_ex->Visible = false;
			 back_ex->Visible = false;
		 }
private: System::Void back_ex_Click(System::Object^  sender, System::EventArgs^  e) {
			 Expense * temp = new Expense();
			 if(choise_exp1->Checked)
				 temp->_purpose = FUEL;
			 else
				 if(choise_exp2->Checked)
					 temp->_purpose = REPAIR;
				else
					if(choise_exp3->Checked)
						temp->_purpose = FINES;
					else
					{
						Form^ f = gcnew prevent(7);
						f->ShowDialog();
						return;
						delete temp;
					}
			if(text_ad_ex1->Text == "")
			 {
				 Form^ f = gcnew prevent(2);
				 f->ShowDialog();
				 return;
			 }	 
			 string temp1;
			 MarshalString(text_ad_ex1->Text,temp1);
			 if(!all_of(temp1.begin(), temp1.end(), unPred()))
			 {
			  	 Form^ f = gcnew prevent(11);
				 f->ShowDialog();
				 return;
			 }
			 if( System::Int32::Parse(text_ad_ex1->Text) <=0)
			 {
				 Form^ f = gcnew prevent(10);
				 f->ShowDialog();
				 return;
			 }
			 temp->_amount = Convert::ToDouble(text_ad_ex1->Text);
			 temp->_date->tm_year = text_ad_ex2->Value.Year;
			 temp->_date->tm_mon = text_ad_ex2->Value.Month;
			 temp->_date->tm_mday = text_ad_ex2->Value.Day;
			 (*vectdata2).push_back(temp);
			 temp = nullptr;
			 
			 lab_main->Text = "�������";
			 add_exp->Visible = true;
			 show_exp->Visible = true;
			 back_main_ex->Visible = true;
			 form_report_exp->Visible = true;
			 lab_ad_ex1->Visible = false;
			 lab_ad_ex2->Visible = false;
			 choise_exp1->Visible = false;
			 choise_exp2->Visible = false;
			 choise_exp3->Visible = false;
			 text_ad_ex1->Visible = false;
			 text_ad_ex2->Visible = false;
			 cancel_ad_ex->Visible = false;
			 back_ex->Visible = false;
			 choise_exp1->Checked = false;
			 choise_exp2->Checked = false;
			 choise_exp3->Checked = false;
			 text_ad_ex1->Text = "";
		 }


private: System::Void show_exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_exp->Visible = false;
			 show_exp->Visible = false;
			 form_report_exp->Visible = false;
			 back_main_ex->Visible = false;
			 lab_main->Text = "��������";
			 back_ex2->Visible = true;
			 text_show_allex->Visible = true;
			 lab_del_ex->Visible = true;
			 text_del_ex->Visible = true;
			 del_ex->Visible = true;
			 String^ of = "";
			 for(int i = 0; i<vectdata2->size(); i++)
				 of+=(i+1).ToString() + ". " + str_date((*vectdata2)[i]->_date) + "  " + 
				 (*vectdata2)[i]->_amount + "p. ��: " +
				 gcnew System::String(expense_to_str_rus((*vectdata2)[i]->_purpose).c_str()) + "\r\n";
			 text_show_allex->Text = of;
		 }
private: System::Void back_ex2_Click(System::Object^  sender, System::EventArgs^  e) {
			 lab_main->Text = "�������";
			 back_ex2->Visible = false;
			 text_show_allex->Visible = false;
			 lab_del_ex->Visible = false;
			 text_del_ex->Visible = false;
			 add_exp->Visible = true;
			 show_exp->Visible = true;
			 form_report_exp->Visible = true;
			 back_main_ex->Visible = true;
			 del_ex->Visible = false;
		 }
private: System::Void del_ex_Click(System::Object^  sender, System::EventArgs^  e) {
			if(text_del_ex->Text == "")
			 {
				 Form^ f1 = gcnew prevent(8);
				 f1->ShowDialog();
				 return;
			 }
			 string temp1;
			 MarshalString(text_del_ex->Text,temp1);
			 if(!all_of(temp1.begin(), temp1.end(), unPred()))
			 {
			  	 Form^ f1 = gcnew prevent(13);
				 f1->ShowDialog();
				 text_del_ex->Text = "";
				 return;
			 }
			 int j = System::Int32::Parse(text_del_ex->Text) - 1;

			 if(j < 0 || j > vectdata1->size())
			 {
				 Form^ f1 = gcnew prevent(9);
				 f1->ShowDialog();
				 text_del_ex->Text = "";
				 return;
			 }
			 Form^ f = gcnew del(vectdata2, j);
			 f->ShowDialog();
			 text_del_ex->Text = "";
			 String^ of = "";
			 for(int i = 0; i<vectdata2->size(); i++)
				 of+=(i+1).ToString() + ". " + str_date((*vectdata2)[i]->_date) + "  " + 
				 (*vectdata2)[i]->_amount + "p. ��: " +
				 gcnew System::String(expense_to_str_rus((*vectdata2)[i]->_purpose).c_str()) + "\r\n";
			 text_show_allex->Text = of;
		 }

private: System::Void form_report_exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 add_exp->Visible = false;
			 show_exp->Visible = false;
			 form_report_exp->Visible = false;
			 back_main_ex->Visible = false;
			 lab_main->Text = "����� ������. �������� � �����: " +
				"\r\n"+ gcnew System::String(file_expense_report(*vectdata2).c_str());
			 but_good1->Visible = true;
		 }
private: System::Void but_good1_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(!archive_flag){			 
				lab_main->Text = "���������� �ר� ��������������";
				trip->Visible = true;
			    exp->Visible = true;
				form_report->Visible = true;
				exit_main->Visible = true;
				but_good1->Visible = false;
				arc_but->Visible = true;
			 }
			 else{
				lab_main->Text = "�����";
				but_good1->Visible = false;
				but_arc_trip->Visible = true;
			    but_arc_exp->Visible = true;
			    but_form_exp->Visible = true;
			    but_back_main->Visible = true;
				form_report->Visible = true;
			 }
		 }


		//������������ ������
private: System::Void form_report_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(!archive_flag){
			 trip->Visible = false;
			 exp->Visible = false;
			 form_report->Visible = false;
			 exit_main->Visible = false;
			 logo->Visible = false;
			 arc_but->Visible = false;
			 lab_main->Text = "����� ������. �������� � �����: " 
				 + "\r\n" + gcnew System::String(file_income_report(*vectdata2, *vectdata1).c_str());
			 }
			 else{
				 but_arc_trip->Visible = false;
				 but_arc_exp->Visible = false;
				 but_form_exp->Visible = false;
				 but_back_main->Visible = false;
				 form_report->Visible = false;
				 lab_main->Text = "����� ������. �������� � �����: " 
				 + "\r\n" + gcnew System::String(file_income_report(*arc_vectdata2, *arc_vectdata1).c_str());
			 }
			 but_good1->Visible = true;
		 }

		
		//�����
private: System::Void arc_but_Click(System::Object^  sender, System::EventArgs^  e) {
			 trip->Visible = false;
			 exp->Visible = false;
			 form_report->Visible = false;
			 logo->Visible = false;
			 arc_but->Visible = false;
			 exit_main->Visible = false;
			 lab_main->Text ="�����";
			 lab_arc1->Visible = true;
			 lab_arc2->Visible = true;
			 but_arc1->Visible = true;



			 cho_mo->Visible = true;
			 cho_year->Visible = true;
			 but_arc_back->Visible = true;
		 }
private: System::Void but_arc_back_Click(System::Object^  sender, System::EventArgs^  e) {
			 trip->Visible = true;
			 exp->Visible = true;
			 form_report->Visible = true;
			 logo->Visible = true;
			 arc_but->Visible = true;
			 exit_main->Visible = true;
			 lab_main->Text ="���������� �ר� ��������������";
			 lab_arc1->Visible = false;
			 lab_arc2->Visible = false;
			 but_arc1->Visible = false;
			 cho_mo->Visible = false;
			 cho_year->Visible = false;
			 but_arc_back->Visible = false;
			 archive_flag = false;
		 }
private: System::Void but_arc1_Click(System::Object^  sender, System::EventArgs^  e) {
			 string name = "";
			 MarshalString("truck" + cho_mo->Value + "_" + 
				 System::Decimal::operator-(cho_year->Value, cho_year->Minimum) + ".txt", name);
			 arc_vectdata1 = new vector<Truck*>();
			 load_trucks_from_file(*arc_vectdata1, name);
			 name = "";
			 MarshalString("expense" + cho_mo->Value + "_" + 
				 System::Decimal::operator-(cho_year->Value, cho_year->Minimum) + ".txt", name);
			 arc_vectdata2 = new vector<Expense*>();
			 load_expenses_from_file(*arc_vectdata2, name);
			 lab_arc1->Visible = false;
			 lab_arc2->Visible = false;
			 but_arc1->Visible = false;
			 cho_mo->Visible = false;
			 cho_year->Visible = false;
			 but_arc_back->Visible = false;
			 archive_flag = true;
			 but_arc_trip->Visible = true;
			 but_arc_exp->Visible = true;
			 form_report->Visible = true;
			 but_form_exp->Visible = true;
			 but_back_main->Visible = true;
		 }
private: System::Void but_back_main_Click(System::Object^  sender, System::EventArgs^  e) {
			 lab_main->Text = "���������� �ר� ��������������";
			 archive_flag = false;
			 but_arc_trip->Visible = false;
			 but_arc_exp->Visible = false;
			 but_form_exp->Visible = false;
			 but_back_main->Visible = false;
			 trip->Visible = true;
			 exp->Visible = true;
			 logo->Visible = true;
			 arc_but->Visible = true;
			 exit_main->Visible = true;
			 delete arc_vectdata1;
			 delete arc_vectdata2;
			 arc_vectdata1 = nullptr;
			 arc_vectdata2 = nullptr;
		 }

private: System::Void but_arc_trip_Click(System::Object^  sender, System::EventArgs^  e) {
			 but_arc_trip->Visible = false;
			 but_arc_exp->Visible = false;
			 but_form_exp->Visible = false;
			 but_back_main->Visible = false;
			 text_show_truck->Visible = true;
			 but_back_arc->Visible = true;
			 lab_main->Text = "�������� ������";
			 String^ of = "";
			 for(int j = 0; j<arc_vectdata1->size(); j++)
			 {
				 data1 = (*arc_vectdata1)[j];
				 of+= (j+1).ToString() + ". " + gcnew System::String(data1->_descr.c_str())+"\r\n���� �����: " + 
			     str_date(data1->_truck_day) + "\r\n���� ������� �����: " + str_date(data1->_account_day)+
				 "\r\n������ �������: " + (data1->_fee).ToString() +"�.\r\n";
				 if(data1->_got_fee)
					 of+="���� ��������� �������: " + str_date(data1->_fee_day);
				 else
				 {
					 tm * d = data1->presumeDate();
					 of+="����������������� ���� ��������� �������: " + str_date(d);
					 delete d;
				 }
			 data1 = nullptr;
			 of+="\r\n"; 
			 }
			 text_show_truck->Text = of;
		 }
private: System::Void but_back_arc_Click(System::Object^  sender, System::EventArgs^  e) {
			 but_arc_trip->Visible = true;
			 but_arc_exp->Visible = true;
			 but_form_exp->Visible = true;
			 but_back_main->Visible = true;
			 text_show_truck->Visible = false;
			 text_show_truck->Text = "";
			 but_back_arc->Visible = false;
			 lab_main->Text = "�����";
		 }
private: System::Void but_arc_exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 but_arc_trip->Visible = false;
			 but_arc_exp->Visible = false;
			 but_form_exp->Visible = false;
			 but_back_main->Visible = false;
			 text_show_truck->Visible = true;
			 but_back_arc->Visible = true;
			 lab_main->Text = "�������� ��������";
			 String^ of = "";
			 for(int i = 0; i<arc_vectdata2->size(); i++)
				 of+=(i+1).ToString() + ". " + str_date((*arc_vectdata2)[i]->_date) + "  " + 
				 (*arc_vectdata2)[i]->_amount + "p. ��: " +
				 gcnew System::String(expense_to_str_rus((*arc_vectdata2)[i]->_purpose).c_str()) + "\r\n";
			 text_show_truck->Text = of;
		 }


private: System::Void but_form_exp_Click(System::Object^  sender, System::EventArgs^  e) {
			 but_arc_trip->Visible = false;
			 but_arc_exp->Visible = false;
			 but_form_exp->Visible = false;
			 but_back_main->Visible = false;
			 form_report->Visible = false;
			 lab_main->Text = "����� ������. �������� � �����: " +
				"\r\n"+ gcnew System::String(file_expense_report(*arc_vectdata2).c_str());
			 but_good1->Visible = true;
		 }
};
}