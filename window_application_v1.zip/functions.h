#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <string>

std::string create_truck_filename(int i = 0);
void load_trucks_from_file(vector<Truck*> & v, string name);

std::string create_exp_filename();
void load_expenses_from_file(vector<Expense*> & v, string name);  //������� �������� ��������

//���������� String^
String^ str_date(const tm * date);

void save_trucks(const vector<Truck*> & v);

bool check_all_trucks(const vector<Truck*> & v, vector<Truck*> & c);

void save_expenses(const vector<Expense*> & v);

string file_expense_report(const vector<Expense*> & v);

string file_income_report(const vector<Expense*> & exp, const vector<Truck*> & trucks);

#endif