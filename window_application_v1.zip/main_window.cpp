#include "main_window.h"
#include "Truck.h"
#include <locale>
#include "Expenses.h"
#include "functions.h"
#include <vector>

using namespace System;
using namespace System::Windows::Forms;

vector<Truck*> trucks;
vector<Expense*> exps;

void MarshalString ( String ^ s, string& os ) {  
   using namespace Runtime::InteropServices;  
   const char* chars =   
      (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();  
   os = chars;  
   Marshal::FreeHGlobal(IntPtr((void*)chars));  
}  

void ElAddTruck(Truck * q){ trucks.push_back(q);}

void ElAddExp(Expense * q){	exps.push_back(q);}

[STAThreadAttribute]
void main(array<String^>^ args) {
	setlocale(LC_ALL, "Russian");
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	trucking::main_window form1(&trucks, &exps);
	Application::Run(%form1);
}