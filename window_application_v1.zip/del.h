#pragma once
#include "Truck.h"
#include <vector>
#include "Expenses.h"

namespace trucking {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� del
	/// </summary>
	public ref class del : public System::Windows::Forms::Form
	{
		vector<Truck*> * v1;
		Truck* vd1;
		int i;
		vector<Expense*> * v2;
		Expense* vd2;

	public:
		del(vector<Truck*> * v, int j):v1(v), i(j), v2(nullptr), vd2(nullptr)
		{
			vd1 = (*v1)[i];
			InitializeComponent();
		}
		del(vector<Expense*> * v, int j):v2(v), i(j), v1(nullptr), vd1(nullptr)
		{
			vd2 = (*v2)[i];
			InitializeComponent();
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~del()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(151, 174);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(107, 60);
			this->button1->TabIndex = 1;
			this->button1->Text = L"������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &del::button1_Click);
			// 
			// button2
			// 
			this->button2->Font = (gcnew System::Drawing::Font(L"v_CCRatatatat", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(22, 174);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(107, 60);
			this->button2->TabIndex = 2;
			this->button2->Text = L"��";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &del::button2_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(28, 20);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(254, 33);
			this->label1->TabIndex = 3;
			this->label1->Text = L"�� �������������";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 20.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(49, 75);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(228, 33);
			this->label2->TabIndex = 4;
			this->label2->Text = L"������ �������\?";
			// 
			// del
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 262);
			this->ControlBox = false;
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"del";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
			this->Text = L"�������� ��������";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 Close();
			 }
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
				if(vd1 != nullptr)
				{
					(*v1).erase((*v1).begin() + i);
					delete vd1;
					vd1 = nullptr;
					Close();
				}
				else
					if(vd2!=nullptr)
					{
						(*v2).erase((*v2).begin() + i);
						delete vd2;
						vd1 = nullptr;
						Close();
					}
			 }
	};
}